---
title: "The Great Gatsby Bootcamp"
date: "2019-04-04"
---

I just launched a new bootcamp!

![Grass](./grass.png)

## Topics Covered

1. Gatsby
2. GraphQL
3. React